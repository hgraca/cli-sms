<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use CM\PhpExtension\Test\AbstractUnitTest;
#if (${TESTED_NAME} && ${NAMESPACE} && !${TESTED_NAMESPACE})
use ${TESTED_NAME};
#elseif (${TESTED_NAME} && ${TESTED_NAMESPACE} && ${NAMESPACE} != ${TESTED_NAMESPACE})
use ${TESTED_NAMESPACE}\\${TESTED_NAME};
#end

/**
 * @small
 * @group unit
 */
final class ${NAME} extends AbstractUnitTest
{
    /**
     * @test
     * @dataProvider provideSomeData
     */
    public function retrieves_component_content(): void
    {
    }

    public function provideSomeData()
    {
        return [
            '' => [],
            '' => [],
        ];
    }
}